//
//  AppRouter.swift
//  Gradit
//

import SwiftUI
import Observation

/// Every pushable screen in the signed-in app.
enum Route: Hashable {
    case userDetail(User)
    case feature(DashboardFeature)

    @ViewBuilder
    var destination: some View {
        switch self {
        case .userDetail(let user):
            Text(user.name)
                .navigationTitle(user.name)
        case .feature(let feature):
            FeaturePlaceholderView(feature: feature)
        }
    }
}

/// Selected bottom tab and one navigation path per tab.
@Observable
final class AppRouter {
    var selectedTab: DashboardTab = .home
    private var paths: [DashboardTab: NavigationPath] = [:]

    func path(for tab: DashboardTab) -> Binding<NavigationPath> {
        Binding(
            get: { self.paths[tab] ?? NavigationPath() },
            set: { self.paths[tab] = $0 }
        )
    }

    func isAtRoot(_ tab: DashboardTab) -> Bool {
        paths[tab]?.isEmpty ?? true
    }

    /// Pushes onto the selected tab's stack.
    func push(_ route: Route) {
        paths[selectedTab, default: NavigationPath()].append(route)
    }

    /// Tapping the selected tab again pops it to its root.
    func select(_ tab: DashboardTab) {
        if tab == selectedTab {
            paths[tab] = NavigationPath()
        } else {
            selectedTab = tab
        }
    }

    func popToRoot() {
        paths[selectedTab] = NavigationPath()
    }

    func reset() {
        selectedTab = .home
        paths = [:]
    }
}
