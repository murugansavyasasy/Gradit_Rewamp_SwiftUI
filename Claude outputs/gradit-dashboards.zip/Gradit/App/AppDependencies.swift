//
//  AppDependencies.swift
//  Gradit
//

import Foundation
import Observation

/// Simple dependency container injected through the SwiftUI environment.
@Observable
final class AppDependencies {
    let apiClient: APIClient
    let userService: UserServiceProtocol
    let authService: AuthServiceProtocol
    let dashboardService: DashboardServiceProtocol

    init(
        apiClient: APIClient,
        userService: UserServiceProtocol,
        authService: AuthServiceProtocol,
        dashboardService: DashboardServiceProtocol
    ) {
        self.apiClient = apiClient
        self.userService = userService
        self.authService = authService
        self.dashboardService = dashboardService
    }

    static var live: AppDependencies {
        let client = APIClient(baseURL: AppConfig.baseURL)
        if AppConfig.useMockServices {
            return AppDependencies(
                apiClient: client,
                userService: MockUserService(),
                authService: MockAuthService(),
                dashboardService: MockDashboardService()
            )
        }
        return AppDependencies(
            apiClient: client,
            userService: UserService(client: client),
            authService: AuthService(client: client),
            dashboardService: DashboardService(client: client)
        )
    }

    static var preview: AppDependencies {
        AppDependencies(
            apiClient: APIClient(baseURL: AppConfig.baseURL),
            userService: MockUserService(),
            authService: MockAuthService(latency: .milliseconds(400)),
            dashboardService: MockDashboardService(latency: .milliseconds(300))
        )
    }
}
